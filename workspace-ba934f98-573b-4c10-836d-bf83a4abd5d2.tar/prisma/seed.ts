import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Hash password untuk admin
  const adminPassword = await bcrypt.hash('admin123', 10)

  // Buat user admin
  const admin = await prisma.user.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      password: adminPassword,
      name: 'Administrator',
      email: 'admin@sdn208.sch.id',
      role: 'ADMIN'
    }
  })

  console.log('✅ Admin user created:', admin.username)

  // Hash password untuk guru contoh
  const guruPassword = await bcrypt.hash('guru123', 10)

  // Buat user guru
  const guruUser = await prisma.user.upsert({
    where: { username: 'guru1' },
    update: {},
    create: {
      username: 'guru1',
      password: guruPassword,
      name: 'Budi Santoso',
      email: 'budi@sdn208.sch.id',
      role: 'GURU'
    }
  })

  // Buat data guru
  const guru = await prisma.guru.upsert({
    where: { userId: guruUser.id },
    update: {},
    create: {
      userId: guruUser.id,
      nip: '198001012005011001',
      nama: 'Budi Santoso',
      mapel: 'Matematika',
      kelas: 'Kelas 1,2',
      telp: '081234567890'
    }
  })

  console.log('✅ Guru user created:', guru.nama)

  // Hash password untuk siswa contoh
  const siswaPassword = await bcrypt.hash('siswa123', 10)

  // Buat user siswa
  const siswaUser = await prisma.user.upsert({
    where: { username: 'siswa1' },
    update: {},
    create: {
      username: 'siswa1',
      password: siswaPassword,
      name: 'Ahmad Rizky',
      email: 'ahmad@siswa.sch.id',
      role: 'SISWA'
    }
  })

  // Buat data siswa
  const siswa = await prisma.siswa.upsert({
    where: { userId: siswaUser.id },
    update: {},
    create: {
      userId: siswaUser.id,
      nis: '2024001',
      nama: 'Ahmad Rizky',
      kelas: 'Kelas 1A',
      telp: '081234567891',
      alamat: 'Jl. Luginasari No. 10',
      namaOrtu: 'Siti Aminah',
      telpOrtu: '081234567892'
    }
  })

  console.log('✅ Siswa user created:', siswa.nama)

  console.log('🎉 Seeding completed!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
