'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Lock, 
  GraduationCap, 
  Users, 
  BookOpen, 
  ClipboardCheck, 
  ShieldAlert, 
  Phone,
  MapPin,
  LogOut,
  ChevronRight,
  School,
  Star,
  ExternalLink,
  User,
  Loader2
} from 'lucide-react'

type ViewState = 'login' | 'dashboard' | 'learning' | 'exam' | 'complaint' | 'data-siswa' | 'data-guru'

interface User {
  id: string
  username: string
  name: string
  email?: string
  role: 'ADMIN' | 'GURU' | 'SISWA'
  createdAt: string
  updatedAt: string
  guru?: {
    id: string
    nip?: string
    nama: string
    mapel?: string
    kelas?: string
    telp?: string
  }
  siswa?: {
    id: string
    nis?: string
    nama: string
    kelas?: string
    telp?: string
    alamat?: string
  }
}

export default function SDNPortal() {
  const [viewState, setViewState] = useState<ViewState>('login')
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loginError, setLoginError] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [dataSiswa, setDataSiswa] = useState<any[]>([])
  const [dataGuru, setDataGuru] = useState<any[]>([])
  const [isLoadingData, setIsLoadingData] = useState(false)

  // Cek login status saat mount
  useEffect(() => {
    checkLoginStatus()
  }, [])

  // Cek apakah user sudah login
  const checkLoginStatus = async () => {
    try {
      const response = await fetch('/api/auth/me')
      if (response.ok) {
        const data = await response.json()
        if (data.success && data.user) {
          setCurrentUser(data.user)
          setIsLoggedIn(true)
          setViewState('dashboard')
        }
      }
    } catch (error) {
      console.error('Check login error:', error)
    }
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setLoginError('')

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      })

      const data = await response.json()

      if (!response.ok) {
        setLoginError(data.error || 'Terjadi kesalahan saat login')
        return
      }

      if (data.success) {
        setCurrentUser(data.user)
        setIsLoggedIn(true)
        setViewState('dashboard')
        setUsername('')
        setPassword('')
      }
    } catch (error) {
      setLoginError('Terjadi kesalahan jaringan')
      console.error('Login error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
      })
    } catch (error) {
      console.error('Logout error:', error)
    } finally {
      setCurrentUser(null)
      setIsLoggedIn(false)
      setViewState('login')
      setUsername('')
      setPassword('')
      setLoginError('')
    }
  }

  const getPublicIP = async () => {
    try {
      const response = await fetch('https://api.ipify.org?format=json')
      const data = await response.json()
      return data.ip
    } catch {
      return 'localhost'
    }
  }

  const openEraport = async () => {
    const ip = await getPublicIP()
    window.open(`http://${ip}:8535`, '_blank')
  }

  const openDapodik = async () => {
    const ip = await getPublicIP()
    window.open(`http://${ip}:5774`, '_blank')
  }

  // Fetch data siswa
  const fetchDataSiswa = async () => {
    setIsLoadingData(true)
    try {
      const response = await fetch('/api/siswa')
      const data = await response.json()
      if (data.success) {
        setDataSiswa(data.data)
      }
    } catch (error) {
      console.error('Fetch siswa error:', error)
    } finally {
      setIsLoadingData(false)
    }
  }

  // Fetch data guru
  const fetchDataGuru = async () => {
    setIsLoadingData(true)
    try {
      const response = await fetch('/api/guru')
      const data = await response.json()
      if (data.success) {
        setDataGuru(data.data)
      }
    } catch (error) {
      console.error('Fetch guru error:', error)
    } finally {
      setIsLoadingData(false)
    }
  }

  // Load data saat view berubah
  useEffect(() => {
    if (viewState === 'data-siswa' && dataSiswa.length === 0) {
      fetchDataSiswa()
    } else if (viewState === 'data-guru' && dataGuru.length === 0) {
      fetchDataGuru()
    }
  }, [viewState])

  // Login View
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-gray-100 p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <Card className="shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="space-y-4 pb-6">
              <motion.div 
                initial={{ scale: 0.8 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5 }}
                className="flex flex-col items-center space-y-4"
              >
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center shadow-lg">
                  <School className="w-14 h-14 text-blue-600" />
                </div>
                <div className="text-center space-y-2">
                  <CardTitle className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent">
                    SDN 208 LUGINASARI
                  </CardTitle>
                  <CardTitle className="text-xl font-bold text-gray-700">
                    SUKAGALIH KOTA BANDUNG
                  </CardTitle>
                  <CardDescription className="text-sm text-gray-500 mt-2">
                    Unggul Berprestasi, Berkarakter dalam Budaya
                  </CardDescription>
                </div>
              </motion.div>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username" className="text-sm font-medium">Username</Label>
                  <Input
                    id="username"
                    type="text"
                    placeholder="Masukkan username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="h-11"
                    disabled={isLoading}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password" className="text-sm font-medium">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Masukkan password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-11"
                    disabled={isLoading}
                  />
                </div>
                {loginError && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="text-sm text-red-500 text-center bg-red-50 p-2 rounded"
                  >
                    {loginError}
                  </motion.div>
                )}
                <Button 
                  type="submit" 
                  className="w-full h-11 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium shadow-lg"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Memproses...
                    </>
                  ) : (
                    'Masuk'
                  )}
                </Button>
                <div className="text-center text-sm text-gray-500 mt-4">
                  <p className="font-semibold mb-2">Akun Demo:</p>
                  <p>Admin: admin / admin123</p>
                  <p>Guru: guru1 / guru123</p>
                  <p>Siswa: siswa1 / siswa123</p>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    )
  }

  // Dashboard View
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 via-white to-gray-100">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-3"
            >
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setViewState('dashboard')}
                className="font-semibold text-blue-700"
              >
                <School className="w-5 h-5 mr-2" />
                SDN 208 LUGINASARI
              </Button>
              {currentUser && (
                <Badge variant="outline" className="ml-2">
                  <User className="w-3 h-3 mr-1" />
                  {currentUser.name} ({currentUser.role})
                </Badge>
              )}
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
            >
              <Button
                variant="outline"
                size="sm"
                onClick={handleLogout}
                className="border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Keluar
              </Button>
            </motion.div>
          </div>
        </div>
      </header>

      {/* Hero Section - Only on Dashboard */}
      <AnimatePresence>
        {viewState === 'dashboard' && (
          <motion.section
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="relative bg-gradient-to-r from-blue-600 via-blue-700 to-gray-800 text-white py-16 overflow-hidden"
          >
            {/* Watermark Overlay */}
            <div className="absolute inset-0 opacity-10 pointer-events-none">
              <div className="w-full h-full flex items-center justify-center">
                <div className="w-[600px] h-[400px] bg-gradient-to-br from-white/20 to-transparent rounded-full blur-3xl" />
              </div>
            </div>
            
            <div className="container mx-auto px-4 relative z-10">
              <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                <motion.div 
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                  className="flex-1 text-center md:text-left"
                >
                  <Badge className="mb-4 bg-white/20 text-white border-white/30">
                    Portal Resmi
                  </Badge>
                  <h1 className="text-4xl md:text-5xl font-bold mb-4">
                    SDN 208 LUGINASARI
                  </h1>
                  <h2 className="text-2xl md:text-3xl font-semibold mb-6 text-blue-100">
                    SUKAGALIH KOTA BANDUNG
                  </h2>
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-6 py-3 rounded-full"
                  >
                    <Star className="w-5 h-5 text-yellow-300" />
                    <span className="text-lg font-medium">Unggul Berprestasi, Berkarakter dalam Budaya</span>
                  </motion.div>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3 }}
                  className="w-64 h-64 md:w-80 md:h-80 bg-white/10 backdrop-blur-sm rounded-2xl shadow-2xl overflow-hidden border-4 border-white/20"
                >
                  <iframe
                    src="https://drive.google.com/file/d/1XzvwujSHBxY4dZHttiC2GCjMA_zJJj1e/preview"
                    width="100%"
                    height="100%"
                    className="border-0"
                  />
                </motion.div>
              </div>
            </div>

            {/* Decorative Watermark Image */}
            <div className="absolute right-0 bottom-0 opacity-5 pointer-events-none">
              <iframe
                src="https://drive.google.com/file/d/1LRfgs0KlvkPm6WBi3Iv8N79olDNwCMHH/preview"
                width="640"
                height="480"
                className="border-0"
              />
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {/* Dashboard Grid */}
          {viewState === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              {/* Quick Access Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-4"
              >
                <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 border-blue-200 hover:border-blue-400">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-2">
                        <h3 className="text-lg font-bold text-gray-800">E-Raport</h3>
                        <p className="text-sm text-gray-500">Akses nilai raport siswa</p>
                      </div>
                      <Button
                        onClick={openEraport}
                        className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Buka
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 border-blue-200 hover:border-blue-400">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-2">
                        <h3 className="text-lg font-bold text-gray-800">Dapodik</h3>
                        <p className="text-sm text-gray-500">Sistem data pokok pendidikan</p>
                      </div>
                      <Button
                        onClick={openDapodik}
                        className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Buka
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Main Menu Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  {
                    id: 'data-siswa',
                    icon: Users,
                    title: 'Data Siswa',
                    description: 'Informasi data siswa sekolah',
                    color: 'from-green-500 to-green-600',
                    delay: 0.2
                  },
                  {
                    id: 'data-guru',
                    icon: Users,
                    title: 'Data Guru',
                    description: 'Profil dan data guru',
                    color: 'from-purple-500 to-purple-600',
                    delay: 0.3
                  },
                  {
                    id: 'learning',
                    icon: BookOpen,
                    title: 'Pembelajaran Interaktif',
                    description: 'Materi dan pembelajaran digital',
                    color: 'from-blue-500 to-blue-600',
                    delay: 0.4
                  },
                  {
                    id: 'exam',
                    icon: ClipboardCheck,
                    title: 'Tes atau Ujian Siswa',
                    description: 'Platform ujian online',
                    color: 'from-orange-500 to-orange-600',
                    delay: 0.5
                  },
                  {
                    id: 'complaint',
                    icon: ShieldAlert,
                    title: 'Pengaduan Kekerasan/Bullying',
                    description: 'Formulir laporan pengaduan',
                    color: 'from-red-500 to-red-600',
                    delay: 0.6
                  }
                ].map((item) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: item.delay }}
                  >
                    <Button
                      onClick={() => setViewState(item.id as ViewState)}
                      variant="outline"
                      className={`w-full h-full p-6 flex flex-col items-start space-y-3 text-left border-2 bg-gradient-to-br ${item.color} to-white hover:shadow-xl transition-all duration-300 group`}
                    >
                      <div className="bg-white/20 backdrop-blur-sm p-3 rounded-lg group-hover:scale-110 transition-transform duration-300">
                        <item.icon className="w-8 h-8 text-white" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="text-lg font-bold text-white">{item.title}</h3>
                        <p className="text-sm text-white/90">{item.description}</p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-white/70 ml-auto group-hover:translate-x-2 transition-transform duration-300" />
                    </Button>
                  </motion.div>
                ))}
              </div>

              {/* Contact Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
              >
                <Card className="shadow-lg border-0 bg-gradient-to-br from-gray-50 to-white">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Phone className="w-5 h-5 text-blue-600" />
                      Hubungi Kami
                    </CardTitle>
                    <CardDescription>Informasi kontak dan lokasi sekolah</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-3">
                        <div className="flex items-start gap-3">
                          <MapPin className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                          <div>
                            <h4 className="font-semibold text-gray-800">Alamat Sekolah</h4>
                            <p className="text-sm text-gray-600 mt-1">
                              Jl. Luginasari No. 208, Sukagalih<br />
                              Kec. Sukajadi, Kota Bandung<br />
                              Provinsi Jawa Barat
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Phone className="w-5 h-5 text-blue-600 flex-shrink-0" />
                          <div>
                            <h4 className="font-semibold text-gray-800">Nomor Telepon</h4>
                            <p className="text-sm text-gray-600 mt-1">(022) 2030044</p>
                          </div>
                        </div>
                      </div>
                      <div className="h-48 md:h-auto bg-gray-200 rounded-lg overflow-hidden">
                        <iframe
                          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3961.1234567890123!2d107.58!3d-6.88!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNsKwNTInNDguMCJTIDEwN8KwMzQnNDguMCJF!5e0!3m2!1sen!2sid!4v1234567890"
                          width="100%"
                          height="100%"
                          style={{ border: 0 }}
                          allowFullScreen
                          loading="lazy"
                          referrerPolicy="no-referrer-when-downgrade"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          )}

          {/* Data Siswa View */}
          {viewState === 'data-siswa' && (
            <motion.div
              key="data-siswa"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="flex items-center gap-4">
                <Button variant="outline" onClick={() => setViewState('dashboard')}>
                  <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
                  Kembali
                </Button>
                <h2 className="text-2xl font-bold text-gray-800">Data Siswa</h2>
              </div>
              <Card>
                <CardContent className="p-6">
                  {isLoadingData ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
                      <span className="ml-2">Memuat data...</span>
                    </div>
                  ) : dataSiswa.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left p-3 font-semibold">NIS</th>
                            <th className="text-left p-3 font-semibold">Nama</th>
                            <th className="text-left p-3 font-semibold">Kelas</th>
                            <th className="text-left p-3 font-semibold">Telepon</th>
                            <th className="text-left p-3 font-semibold">Alamat</th>
                          </tr>
                        </thead>
                        <tbody>
                          {dataSiswa.map((siswa) => (
                            <tr key={siswa.id} className="border-b hover:bg-gray-50">
                              <td className="p-3">{siswa.nis || '-'}</td>
                              <td className="p-3 font-medium">{siswa.nama}</td>
                              <td className="p-3">{siswa.kelas || '-'}</td>
                              <td className="p-3">{siswa.telp || '-'}</td>
                              <td className="p-3">{siswa.alamat || '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-12 text-gray-500">
                      <Users className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                      <p>Belum ada data siswa</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Data Guru View */}
          {viewState === 'data-guru' && (
            <motion.div
              key="data-guru"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="flex items-center gap-4">
                <Button variant="outline" onClick={() => setViewState('dashboard')}>
                  <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
                  Kembali
                </Button>
                <h2 className="text-2xl font-bold text-gray-800">Data Guru</h2>
              </div>
              <Card>
                <CardContent className="p-6">
                  {isLoadingData ? (
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
                      <span className="ml-2">Memuat data...</span>
                    </div>
                  ) : dataGuru.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left p-3 font-semibold">NIP</th>
                            <th className="text-left p-3 font-semibold">Nama</th>
                            <th className="text-left p-3 font-semibold">Mapel</th>
                            <th className="text-left p-3 font-semibold">Kelas</th>
                            <th className="text-left p-3 font-semibold">Telepon</th>
                          </tr>
                        </thead>
                        <tbody>
                          {dataGuru.map((guru) => (
                            <tr key={guru.id} className="border-b hover:bg-gray-50">
                              <td className="p-3">{guru.nip || '-'}</td>
                              <td className="p-3 font-medium">{guru.nama}</td>
                              <td className="p-3">{guru.mapel || '-'}</td>
                              <td className="p-3">{guru.kelas || '-'}</td>
                              <td className="p-3">{guru.telp || '-'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-12 text-gray-500">
                      <GraduationCap className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                      <p>Belum ada data guru</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Pembelajaran Interaktif View */}
          {viewState === 'learning' && (
            <motion.div
              key="learning"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="flex items-center gap-4">
                <Button variant="outline" onClick={() => setViewState('dashboard')}>
                  <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
                  Kembali
                </Button>
                <h2 className="text-2xl font-bold text-gray-800">Pembelajaran Interaktif</h2>
              </div>
              <Card>
                <CardHeader>
                  <CardDescription>Pilih materi pembelajaran yang ingin dipelajari</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="kelas1" className="w-full">
                    <TabsList className="grid w-full grid-cols-6 mb-6">
                      <TabsTrigger value="kelas1">Kelas 1</TabsTrigger>
                      <TabsTrigger value="kelas2">Kelas 2</TabsTrigger>
                      <TabsTrigger value="kelas3">Kelas 3</TabsTrigger>
                      <TabsTrigger value="kelas4">Kelas 4</TabsTrigger>
                      <TabsTrigger value="kelas5">Kelas 5</TabsTrigger>
                      <TabsTrigger value="kelas6">Kelas 6</TabsTrigger>
                    </TabsList>
                    <TabsContent value="kelas1" className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {['Matematika', 'Bahasa Indonesia', 'IPAS', 'PPKn'].map((subject) => (
                          <Card key={subject} className="hover:shadow-lg transition-shadow cursor-pointer">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-3">
                                <BookOpen className="w-8 h-8 text-blue-600" />
                                <div>
                                  <h3 className="font-semibold">{subject}</h3>
                                  <p className="text-sm text-gray-500">Materi pembelajaran kelas 1</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="kelas2" className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {['Matematika', 'Bahasa Indonesia', 'IPAS', 'PPKn'].map((subject) => (
                          <Card key={subject} className="hover:shadow-lg transition-shadow cursor-pointer">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-3">
                                <BookOpen className="w-8 h-8 text-blue-600" />
                                <div>
                                  <h3 className="font-semibold">{subject}</h3>
                                  <p className="text-sm text-gray-500">Materi pembelajaran kelas 2</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="kelas3" className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {['Matematika', 'Bahasa Indonesia', 'IPAS', 'PPKn'].map((subject) => (
                          <Card key={subject} className="hover:shadow-lg transition-shadow cursor-pointer">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-3">
                                <BookOpen className="w-8 h-8 text-blue-600" />
                                <div>
                                  <h3 className="font-semibold">{subject}</h3>
                                  <p className="text-sm text-gray-500">Materi pembelajaran kelas 3</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="kelas4" className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {['Matematika', 'Bahasa Indonesia', 'IPAS', 'PPKn'].map((subject) => (
                          <Card key={subject} className="hover:shadow-lg transition-shadow cursor-pointer">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-3">
                                <BookOpen className="w-8 h-8 text-blue-600" />
                                <div>
                                  <h3 className="font-semibold">{subject}</h3>
                                  <p className="text-sm text-gray-500">Materi pembelajaran kelas 4</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="kelas5" className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {['Matematika', 'Bahasa Indonesia', 'IPAS', 'PPKn'].map((subject) => (
                          <Card key={subject} className="hover:shadow-lg transition-shadow cursor-pointer">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-3">
                                <BookOpen className="w-8 h-8 text-blue-600" />
                                <div>
                                  <h3 className="font-semibold">{subject}</h3>
                                  <p className="text-sm text-gray-500">Materi pembelajaran kelas 5</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="kelas6" className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {['Matematika', 'Bahasa Indonesia', 'IPAS', 'PPKn'].map((subject) => (
                          <Card key={subject} className="hover:shadow-lg transition-shadow cursor-pointer">
                            <CardContent className="p-4">
                              <div className="flex items-center gap-3">
                                <BookOpen className="w-8 h-8 text-blue-600" />
                                <div>
                                  <h3 className="font-semibold">{subject}</h3>
                                  <p className="text-sm text-gray-500">Materi pembelajaran kelas 6</p>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Tes atau Ujian View */}
          {viewState === 'exam' && (
            <motion.div
              key="exam"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="flex items-center gap-4">
                <Button variant="outline" onClick={() => setViewState('dashboard')}>
                  <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
                  Kembali
                </Button>
                <h2 className="text-2xl font-bold text-gray-800">Tes atau Ujian Siswa</h2>
              </div>
              <Card>
                <CardHeader>
                  <CardDescription>Pilih ujian yang tersedia</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {[
                      { name: 'Ulangan Harian Matematika', kelas: 'Kelas 1', status: 'Tersedia' },
                      { name: 'Ulangan Harian Bahasa Indonesia', kelas: 'Kelas 1', status: 'Tersedia' },
                      { name: 'Ujian Tengah Semester', kelas: 'Kelas 2', status: 'Segera' },
                      { name: 'Ulangan Harian IPAS', kelas: 'Kelas 3', status: 'Tersedia' },
                      { name: 'Ujian Akhir Semester', kelas: 'Kelas 4', status: 'Segera' },
                      { name: 'Ulangan Harian PPKn', kelas: 'Kelas 5', status: 'Tersedia' },
                    ].map((exam, index) => (
                      <Card key={index} className="hover:shadow-lg transition-all duration-300 hover:scale-105">
                        <CardContent className="p-6">
                          <div className="space-y-3">
                            <Badge variant={exam.status === 'Tersedia' ? 'default' : 'secondary'}>
                              {exam.status}
                            </Badge>
                            <h3 className="font-bold text-lg">{exam.name}</h3>
                            <p className="text-sm text-gray-500">{exam.kelas}</p>
                            <Button className="w-full" disabled={exam.status !== 'Tersedia'}>
                              Mulai Ujian
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Pengaduan Bullying View */}
          {viewState === 'complaint' && (
            <motion.div
              key="complaint"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="flex items-center gap-4">
                <Button variant="outline" onClick={() => setViewState('dashboard')}>
                  <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
                  Kembali
                </Button>
                <h2 className="text-2xl font-bold text-gray-800">Pengaduan Kekerasan/Bullying</h2>
              </div>
              <Card className="border-red-200">
                <CardHeader>
                  <CardTitle className="text-red-700">Formulir Pengaduan</CardTitle>
                  <CardDescription>
                    Laporkan kejadian bullying atau kekerasan secara anonim atau dengan identitas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-6">
                    <div className="space-y-2">
                      <Label>Nama Pelapor (Opsional)</Label>
                      <Input placeholder="Isi nama jika ingin dikenali" />
                    </div>
                    <div className="space-y-2">
                      <Label>Kelas (Opsional)</Label>
                      <Input placeholder="Contoh: Kelas 5A" />
                    </div>
                    <div className="space-y-2">
                      <Label>Tanggal Kejadian *</Label>
                      <Input type="date" required />
                    </div>
                    <div className="space-y-2">
                      <Label>Lokasi Kejadian *</Label>
                      <Input placeholder="Contoh: Di kelas, di kantin, di halaman" required />
                    </div>
                    <div className="space-y-2">
                      <Label>Deskripsi Kejadian *</Label>
                      <Textarea 
                        placeholder="Jelaskan secara rinci kejadian yang dialami atau dilihat..."
                        rows={6}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Nama Korban (Jika diketahui)</Label>
                      <Input placeholder="Nama korban kekerasan/bullying" />
                    </div>
                    <div className="space-y-2">
                      <Label>Nama Pelaku (Jika diketahui)</Label>
                      <Input placeholder="Nama pelaku kekerasan/bullying" />
                    </div>
                    <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                      <p className="text-sm text-red-700">
                        <ShieldAlert className="w-4 h-4 inline mr-2" />
                        Laporan Anda akan ditangani dengan serius dan kerahasiaan terjamin.
                      </p>
                    </div>
                    <Button type="submit" className="w-full bg-red-600 hover:bg-red-700">
                      Kirim Laporan
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="mt-auto bg-gradient-to-r from-gray-800 to-gray-900 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-bold text-lg mb-4">SDN 208 LUGINASARI</h3>
              <p className="text-gray-300 text-sm">
                Unggul Berprestasi, Berkarakter dalam Budaya
              </p>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Kontak</h3>
              <div className="space-y-2 text-sm text-gray-300">
                <p className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  (022) 2030044
                </p>
                <p className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Jl. Luginasari No. 208, Sukagalih
                </p>
              </div>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-4">Tautan Cepat</h3>
              <div className="space-y-2 text-sm text-gray-300">
                <p>E-Raport</p>
                <p>Dapodik</p>
                <p>Pembelajaran Interaktif</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-400">
            <p>&copy; 2025 SDN 208 LUGINASARI SUKAGALIH KOTA BANDUNG. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
